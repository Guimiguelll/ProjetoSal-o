import csv
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk


class SalaoCabelereiro:
    def __init__(self, master):
        self.master = master
        master.title("Salão de Cabelereiro")

        self.clientes_agendados = []  # Lista para armazenar os clientes agendados
        self.clientes_atendidos = []  # Lista para armazenar os clientes atendidos

        # Widgets para entrada de dados dos clientes
        self.label_nome = tk.Label(master, text="Nome do Cliente:")
        self.label_nome.grid(row=0, column=0)

        self.entry_nome = tk.Entry(master)
        self.entry_nome.grid(row=0, column=1)

        self.label_data = tk.Label(master, text="Data do Agendamento :")
        self.label_data.grid(row=1, column=0)

        self.entry_data = tk.Entry(master)
        self.entry_data.grid(row=1, column=1)

        self.label_hora = tk.Label(master, text="Hora do Agendamento :")
        self.label_hora.grid(row=2, column=0)

        self.entry_hora = tk.Entry(master)
        self.entry_hora.grid(row=2, column=1)

        # Botões para agendar, marcar como atendido, excluir, salvar, carregar e ver clientes atendidos
        self.botao_agendar = tk.Button(master, text="Agendar Cliente", command=self.agendar_cliente)
        self.botao_agendar.grid(row=3, column=0)

        self.botao_atendido = tk.Button(master, text="Marcar como Atendido", command=self.marcar_atendido)
        self.botao_atendido.grid(row=3, column=1)

        self.tree_agendados = ttk.Treeview(master, columns=("Nome", "Data", "Hora"), show="headings")
        self.tree_agendados.heading("Nome", text="Nome")
        self.tree_agendados.heading("Data", text="Data")
        self.tree_agendados.heading("Hora", text="Hora")
        self.tree_agendados.grid(row=4, column=0, columnspan=2)

        self.botao_excluir = tk.Button(master, text="Excluir Cliente", command=self.excluir_cliente)
        self.botao_excluir.grid(row=5, column=0, columnspan=2)

        self.botao_salvar = tk.Button(master, text="Salvar Agenda", command=self.salvar_agenda)
        self.botao_salvar.grid(row=6, column=0, columnspan=2)

        self.botao_ver_atendidos = tk.Button(master, text="Ver Clientes Atendidos", command=self.ver_clientes_atendidos)
        self.botao_ver_atendidos.grid(row=7, column=0, columnspan=2)

        self.carregar_agenda()

    # Método para agendar um cliente
    def agendar_cliente(self):
        nome = self.entry_nome.get()
        data = self.entry_data.get()
        hora = self.entry_hora.get()

        # Verifica se todos os campos foram preenchidos
        if nome and data and hora:
            self.clientes_agendados.append((nome, data, hora))  # Adiciona o cliente à lista de agendados
            self.update_table(self.tree_agendados, self.clientes_agendados)  # Atualiza a tabela de agendados
            messagebox.showinfo("Agendamento", f"Cliente '{nome}' agendado para {data} às {hora}.")
            # Limpa os campos de entrada
            self.entry_nome.delete(0, tk.END)
            self.entry_data.delete(0, tk.END)
            self.entry_hora.delete(0, tk.END)
        else:
            messagebox.showerror("Erro", "Por favor, preencha todos os campos.")

    # Método para marcar um cliente como atendido
    def marcar_atendido(self):
        selected_item = self.tree_agendados.selection()
        if selected_item:
            cliente = self.tree_agendados.item(selected_item)['values']
            if cliente:
                valor_servico = self.perguntar_valor_servico()  # Pergunta o valor do serviço
                if valor_servico is not None:
                    observacao = self.perguntar_observacao()  # Pergunta a observação
                    if observacao is not None:
                        cliente_atendido = tuple(cliente) + (valor_servico, observacao)  # Adiciona valor e observação
                        self.clientes_atendidos.append(cliente_atendido)  # Adiciona cliente à lista de atendidos
                        self.clientes_agendados.remove(cliente)  # Remove cliente da lista de agendados
                        self.update_table(self.tree_agendados, self.clientes_agendados)  # Atualiza tabela de agendados
                        self.update_table(self.tree_atendidos, self.clientes_atendidos)  # Atualiza tabela de atendidos
                        messagebox.showinfo("Atendido", f"Cliente '{cliente[0]}' marcado como atendido.")
        else:
            messagebox.showerror("Erro", "Por favor, selecione um cliente agendado.")

    # Método para perguntar o valor do serviço ao usuário
    def perguntar_valor_servico(self):
        valor_servico = simpledialog.askfloat("Valor do Serviço", "Informe o valor do serviço:")
        if valor_servico is not None:
            return f"R${valor_servico:.2f}"  # Formata o valor como moeda (R$)
        else:
            return None

    # Método para perguntar a observação ao usuário
    def perguntar_observacao(self):
        observacao = simpledialog.askstring("Observação", "Informe uma observação:")
        return observacao if observacao else None

    # Método para excluir um cliente da lista de agendamentos
    def excluir_cliente(self):
        selected_item = self.tree_agendados.selection()
        if selected_item:
            cliente = self.tree_agendados.item(selected_item)['values']
            if cliente:
                self.clientes_agendados.remove(cliente)  # Remove o cliente da lista de agendados
                self.update_table(self.tree_agendados, self.clientes_agendados)  # Atualiza a tabela de agendados
                messagebox.showinfo("Exclusão", f"Cliente '{cliente[0]}' excluído com sucesso.")
        else:
            messagebox.showerror("Erro", "Por favor, selecione um cliente agendado.")

    # Método para atualizar uma tabela
    def update_table(self, tree, data):
        tree.delete(*tree.get_children())  # Limpa a tabela
        # Insere os clientes na tabela
        for cliente in data:
            tree.insert("", "end", values=cliente)

    # Método para salvar os agendamentos em um arquivo CSV
    def salvar_agenda(self):
        with open("agenda.csv", mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerows(self.clientes_agendados)  # Escreve os clientes agendados no arquivo CSV
        messagebox.showinfo("Salvo", "Agenda salva com sucesso.")

    # Método para carregar os agendamentos de um arquivo CSV
    def carregar_agenda(self):
        try:
            with open("agenda.csv", mode="r", newline="") as file:
                reader = csv.reader(file)
                self.clientes_agendados = [tuple(row) for row in reader]  # Lê os clientes do arquivo
            self.update_table(self.tree_agendados, self.clientes_agendados)  # Atualiza a tabela de agendados
            messagebox.showinfo("Carregado", "Agenda carregada com sucesso.")
        except FileNotFoundError:
            messagebox.showwarning("Aviso", "Arquivo de agenda não encontrado.")

    # Método para visualizar a lista de clientes atendidos
    def ver_clientes_atendidos(self):
        if self.clientes_atendidos:
            top = tk.Toplevel(self.master)
            top.title("Clientes Atendidos")

            tree = ttk.Treeview(top, columns=("Nome", "Data", "Hora", "Valor do Serviço", "Observação"), show="headings")
            tree.heading("Nome", text="Nome")
            tree.heading("Data", text="Data")
            tree.heading("Hora", text="Hora")
            tree.heading("Valor do Serviço", text="Valor do Serviço")
            tree.heading("Observação", text="Observação")
            tree.grid(row=0, column=0, columnspan=2)

            total_servicos = 0  # Inicializa o total de serviços como zero
            total_clientes = 0  # Inicializa o total de clientes como zero

            for cliente in self.clientes_atendidos:
                nome, data, hora, valor_servico, observacao = cliente  # Desempacota os valores do cliente
                tree.insert("", "end", values=(nome, data, hora, valor_servico, observacao))  # Insere dados na tabela
                total_servicos += float(valor_servico.strip("R$"))  # Adiciona o valor do serviço ao total
                total_clientes += 1  # Incrementa a contagem de clientes

            # Mostra o total de serviços e a contagem de clientes no final da lista de clientes atendidos
            tree.insert("", "end", values=("", f"Total de Clientes: {total_clientes}", "", "", f"Total de Serviços: R${total_servicos:.2f}"))

        else:
            messagebox.showinfo("Sem clientes", "Não há clientes atendidos para mostrar.")


def main():
    root = tk.Tk()
    salao_cabelereiro = SalaoCabelereiro(root)
    root.mainloop()

if __name__ == "__main__":
    main()
